# SDJM Android App project

এইটো SDJM-ৰ Android Studio project source। এই পৰিবেশত APK compile কৰা হোৱা নাই। APK তৈয়াৰ কৰিবলৈ:

## GitHub Actions-ৰ সহায়ত
1. GitHub-ত নতুন repository বনাওক, নাম `SDJM` দিব পাৰে।
2. এই ZIP-ৰ ভিতৰৰ সকলো ফাইল repository-ত upload কৰক (ফোল্ডাৰৰ ভিতৰৰ ফাইলসমূহসহ)।
3. Repository-ৰ **Actions** tab খোলক আৰু **Build SDJM APK** workflow বাছক।
4. **Run workflow** টিপক। Build শেষ হ'লে workflow run খোলক, **Artifacts**-ৰ `SDJM-debug-APK` ডাউনলোড কৰক।
5. ZIP খুলিলে `app-debug.apk` পাব। Android ফোনত ইনষ্টল কৰাৰ আগতে APK-টো নিজৰ project-ৰ পৰা build হৈছে নে নিশ্চিত কৰক।

## স্থানীয়ভাৱে
Android Studio-ত project খুলি Gradle sync কৰক, তাৰ পিছত **Build > Build Bundle(s) / APK(s) > Build APK(s)** বাছক।

## বৰ্তমান সুবিধা
- দেশী সকলোৰে বিষয়ে: https://en.wikipedia.org/wiki/Deshi_people
- জাননী: https://www.facebook.com/share/1DFTyf4hJp/
- যোগাযোগ: 8399025741
- অনলাইন সদস্য ভৰ্তি: নাই

টোকা: জাননী বুটামটোৱে Facebook link খোলে। Facebook-ৰ নতুন post-সমূহ App-ৰ ভিতৰত নিজে নিজে embed হৈ নেদেখায়; সেয়া কৰিবলৈ পৃথক public Page/feed সংযোগৰ প্ৰয়োজন।
